#Graficas
#Pedidos.csv
#Utilidad Final.csv
#Utlizada Previa.csv
#Utilidad Posterior.csv
#Pedidos cancelados.csv
#Pedidos Limpios.csv


from pathlib import Path
from datetime import datetime, timedelta 
from ortools.algorithms.python import knapsack_solver
from flask import Flask, render_template, send_file
import matplotlib.pyplot as plt
import pandas as pd, re, math, sys
from subcarpeta import algoritmo_mochila
import io
import os

app = Flask(__name__)

DATA_FOLDER = os.path.join(os.path.dirname(__file__), 'data')

@app.route('/')
def index():
    return render_template('index.html')

def generar_grafica(nombre_archivo, titulo, columna_x, columna_y):
    ruta_archivo = os.path.join(DATA_FOLDER, nombre_archivo)

    if not os.path.exists(ruta_archivo):
        return f"Archivo {nombre_archivo} no encontrado en /data", 404

    try:
        df = pd.read_csv(ruta_archivo)

        if 'fecha' in columna_x.lower():
            df[columna_x] = pd.to_datetime(df[columna_x], dayfirst=True, errors='coerce')
            df = df.dropna(subset=[columna_x])

        if columna_x not in df.columns or columna_y not in df.columns:
            return f"Las columnas '{columna_x}' o '{columna_y}' no existen en {nombre_archivo}.", 400

        x = df[columna_x]
        y = df[columna_y]

        # Si x no es datetime, convertirlo a string para evitar error de matplotlib
        if not pd.api.types.is_datetime64_any_dtype(x):
            x = x.astype(str)

        # Convertir y a numérico (float) para evitar errores si hay datos no numéricos
        y = pd.to_numeric(y, errors='coerce')
        # Opcional: eliminar filas con valores NaN en y para que la gráfica no falle
        mask = y.notna()
        x = x[mask]
        y = y[mask]

    except Exception as e:
        return f"Error al procesar {nombre_archivo}: {e}", 500

    plt.figure(figsize=(10, 5))
    plt.plot(x, y, marker='o', linestyle='--')
    plt.title(titulo)
    plt.xlabel(columna_x.capitalize())
    plt.ylabel(columna_y.capitalize())
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()

    return send_file(img, mimetype='image/png')

@app.route('/grafica/pedidos')
def grafica_pedidos():
    return generar_grafica('Pedidos.csv', 'Pedidos Totales', 'FECHA FACTURA VENTA', 'LITROS REALES')

@app.route('/grafica/pedidos_cancelados')
def grafica_pedidos_cancelados():
    return generar_grafica('Pedidos_cancelados.csv', 'Pedidos Cancelados', 'fecha_fac', 'Litros Reales')

@app.route('/grafica/utilidad_final')
def grafica_utilidad_final():
    return generar_grafica('Utilidad_final.csv', 'Cambio de Utilidad Mensual', 'Año-Mes', 'Δ Utilidad')

@app.route('/grafica/utilidad_posterior')
def grafica_utilidad_posterior():
    return generar_grafica('Utilidad_posterior.csv', 'Utilidad Posterior', 'Año-Mes', 'Total_Utilidad')

@app.route('/grafica/utilidad_previa')
def grafica_utilidad_previa():
    return generar_grafica('Utilidad_previa.csv', 'Utilidad Previa', 'Año-Mes', 'Total_Utilidad')

@app.route('/grafica/pedidos_limpios')
def grafica_pedidos_limpios():
    return generar_grafica('Pedidos_limpios.csv', 'Pedidos Limpios', 'FECHA', 'LITROS')

@app.route('/ejecutar_mochila', methods=['POST'])
def ejecutar_mochila():
    mensaje = algoritmo_mochila.ejecutar()
    return render_template('resultado.html', mensaje=mensaje)


if __name__ == '__main__':
    app.run(debug=True)
